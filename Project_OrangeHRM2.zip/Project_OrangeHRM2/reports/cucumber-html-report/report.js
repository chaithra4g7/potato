$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/main/resources/Feature/Testcase.feature");
formatter.feature({
  "line": 2,
  "name": "OrangeHRM Website",
  "description": "",
  "id": "orangehrm-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@OrangeHRM"
    }
  ]
});
formatter.scenario({
  "line": 34,
  "name": "",
  "description": "Add a new Paygrade and delete it",
  "id": "orangehrm-website;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 33,
      "name": "@TC05_OrangeHRM"
    }
  ]
});
formatter.step({
  "line": 36,
  "name": "The user opens browser and opens OrangeHRM",
  "keyword": "Given "
});
formatter.step({
  "line": 37,
  "name": "The user login to website",
  "keyword": "When "
});
formatter.step({
  "line": 38,
  "name": "The user will add a new Paygrade",
  "keyword": "And "
});
formatter.step({
  "line": 39,
  "name": "The user will delete the Paygrade",
  "keyword": "Then "
});
formatter.match({
  "location": "PaygradeSteps.the_user_opens_browser_and_opens_OrangeHRM_site()"
});
formatter.result({
  "duration": 40905455400,
  "status": "passed"
});
formatter.match({
  "location": "PaygradeSteps.the_user_login_to_the_website()"
});
formatter.result({
  "duration": 6758843800,
  "status": "passed"
});
formatter.match({
  "location": "PaygradeSteps.the_user_will_add_a_new_Paygrade()"
});
formatter.result({
  "duration": 6926840500,
  "status": "passed"
});
formatter.match({
  "location": "PaygradeSteps.the_user_will_delete_the_Paygrade()"
});
formatter.result({
  "duration": 2551269500,
  "status": "passed"
});
});