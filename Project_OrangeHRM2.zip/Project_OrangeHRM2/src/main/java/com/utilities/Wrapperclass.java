package com.utilities;

import java.io.File;


import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Wrapperclass {
	//to launch the browser
	protected WebDriver driver;
	public void Browser_Launch(String browser) {
		
			
			if (browser.equalsIgnoreCase("firefox")) {
				driver = new FirefoxDriver();
			}
			
			else if (browser.equalsIgnoreCase("chrome")) {
				System.out.println("hello22");
				System.setProperty("webdriver.chrome.driver","C:/Users/aditya/Desktop/chromedriver_win32/chromedriver.exe");
				driver=new ChromeDriver();
			}
      		driver.manage().window().maximize(); 
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.get("https://opensource-demo.orangehrmlive.com/index.php/admin/viewSystemUsers");
		}
	//adding screenshots
	public void screenshot(String path) throws IOException
	{
		TakesScreenshot ts=((TakesScreenshot)driver);
		File Source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(Source,new File(path));
	}
	//quit
	public void Quit() {
		driver.close();
	}
	
	
}
