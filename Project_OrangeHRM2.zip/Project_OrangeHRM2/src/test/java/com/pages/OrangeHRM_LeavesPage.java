package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OrangeHRM_LeavesPage {
//To assign leave	
	
	WebDriver driver;
	
	@FindBy(xpath="//b[text()='Leave']")
	WebElement Leave;
	@FindBy(xpath="//a[text()='Assign Leave']")
	WebElement AssignLeave;
	@FindBy(name="assignleave[txtEmployee][empName]")
	WebElement nameInput;
	@FindBy(xpath="//select[@name='assignleave[txtLeaveType]']")
	WebElement Leavetype;
	@FindBy(xpath="//option[@value='1']")
	WebElement Vacation;
	@FindBy(id="assignleave_txtFromDate")
	WebElement Alfrm;
	@FindBy(linkText="14")
	WebElement Date3;
	@FindBy(id="assignleave_txtToDate")
	WebElement Alto;
	@FindBy(linkText="14")
	WebElement Date4;
	
	@FindBy(id="assignBtn")
	WebElement Assign;
	@FindBy(xpath="//input[@id='confirmOkButton']")
	WebElement ok;
	
// Launching chrome browser	
	public OrangeHRM_LeavesPage(WebDriver driver) {
		this.driver=driver;
			PageFactory.initElements(driver,this);
}
	//using the keyboard operations to add leave details
	public void AssignLeave()
	{
		Leave.click();
		AssignLeave.click();
		nameInput.sendKeys("Steven Edwards");
		nameInput.submit();
		Leavetype.click();
		Vacation.click();
		Leavetype.click();
		Alfrm.click();
		Date3.click();
		Alto.click();
		Date4.click();
	}
//To conform leave	
	public void ConfirmLeave()
	{
		Assign.click();
		ok.click();

	}
}
	